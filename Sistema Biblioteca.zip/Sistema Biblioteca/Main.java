import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();
        Scanner scanner = new Scanner(System.in);

        biblioteca.agregarLibro(new Libro("El Quijote", "Miguel de Cervantes", "12345"));
        biblioteca.agregarLibro(new Libro("Cien años de soledad", "Gabriel García Márquez", "67890"));

        Usuario admin = new Administrador("Alice", "A001");
        Usuario lector = new Lector("Bob", "L001");
        biblioteca.registrarUsuario(admin);
        biblioteca.registrarUsuario(lector);

        System.out.println("Bienvenido al sistema de gestión de bibliotecas");
        biblioteca.listarLibros();
    }
}