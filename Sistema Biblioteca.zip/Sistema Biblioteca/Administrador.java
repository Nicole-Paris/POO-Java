public class Administrador extends Usuario {
    
    public Administrador(String nombre, String id) {
        super(nombre, id);
    }

    @Override
    public void mostrarOpciones() {
        System.out.println("Opciones del administrador:");
        System.out.println("1. Agregar libro");
        System.out.println("2. Eliminar libro");
        System.out.println("3. Listar libros");
    }
}