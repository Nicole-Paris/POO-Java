public class Lector extends Usuario {
    public Lector(String nombre, String id) {
        super(nombre, id);
    }

    @Override
    public void mostrarOpciones() {
        System.out.println("Opciones del lector:");
        System.out.println("1. Consultar libros disponibles");
        System.out.println("2. Pedir libro prestado");
        System.out.println("3. Devolver libro");
    }
}